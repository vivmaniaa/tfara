$(document).ready(function(){
    
 function dynamicSize(){
             var ww = $(window).width();
             var wh = $(window).height();
             /*alert(ww);*/
        
        $('.dark').css({'font-size':ww-(ww*0.98411122144985104270109235352532)+'px'});
         
        /*var perc= 100; //type percent height of slider. Actual height will be this minus nav height.
        var rh = $("div.header").height();
        var newh= wh * (perc/100);
        var fh = newh-rh;
        $('div.dark').css({'height': fh+'px'});*/

        /*var logo=$('div#logo').height();
        alert('logo height is '+logo+'px');*/
        /*if(wh > ww+100){
            alert("Tilt your screen for the better view!");
        }*/
        /*var factheight = $('div.dark').height();
        alert('wh= '+wh+', head height= '+rh+', slider height= '+factheight);*/
        };

        dynamicSize();                            
        $(window).resize(function(){
          dynamicSize();                
       });


      
var bit = $('#bitcounter').attr('class')-1;

if(bit == 0)
    {
    switch (window.location.href) 
        {
        case 'http://localhost/tafara/secondjquerytest.php':
            $('nav a.prev').css({'display': 'none'});   // The 'disable' is set to true so it will disable the any tag with the id of 'prev'.
            break;
        case 'http://localhost/tafara/secondjquerytest.php?Page=1':
            $('nav a.prev').css({'display': 'none'});   // The 'disable' is set to true so it will disable the any tag with the id of 'prev'.
            break;
        case 'http://localhost/tafara/secondjquerytest.php?Pd=1&Page=1':
            $('nav a.prev').css({'display': 'none'});   // The 'disable' is set to true so it will disable the any tag with the id of 'prev'.
            break;  
        default:
            $('nav a.prev').css({'display': ''});
            break;
        }
    
    }

$(".divs div.fact").each(function(e) {
    if (e != 0)
        $(this).hide();
    

// below 2 lines do the same as above line

// var pathname = '/tafara/positiondiv.php'
//if (window.location.href == "http://" + window.location.hostname + pathname ){

//  window.location.href = window.location.href + "?ID=" + demo; }
});

$(".buttonnext").click(function()
{
  bit = bit + 1; // this variable is set for hiding prev button.

if ($(".divs div.fact:visible").next().length != 0)
{
    $('nav a.prev').css({'display': ''});
    $(".divs div.fact:visible").next().show().prev().hide();
// window.location.href = window.location.href + "?ID=" + demo; 
//document.getElementById("demo").innerHTML = demo;
//document.getElementById("demo1").innerHTML = $('.divs div.fact:visible').attr('id');
}
else{     

    var flag_value1 = 'yes';
    if(window.location.href != "http://localhost/tafara/secondjquerytest.php") 
    {

        window.location.href = window.location.href + "&flag=" + flag_value1; 
    }
    else{
        window.location.href = window.location.href + "?flag=" + flag_value1; 
    }
//   $(".divs div.fact:visible").hide();
// $(".divs div.fact:first").show();
}
return false;
});
// alert('Currently you are on very first page. To see more facts click "NEXT" button!');

$(".buttonprev").click(function(){

    bit = bit-1; // this variable is set for hiding prev button.
if (bit == 0)
{
    switch (window.location.href) {
        case 'http://localhost/tafara/secondjquerytest.php':
            $('nav a.prev').css({'display': 'none'});   // The 'disable' is set to true so it will disable the any tag with the id of 'prev'.
            break;
        case 'http://localhost/tafara/secondjquerytest.php?Page=1':
            $('nav a.prev').css({'display': 'none'});   // The 'disable' is set to true so it will disable the any tag with the id of 'prev'.
            break;
        case 'http://localhost/tafara/secondjquerytest.php?Pd=1&Page=1':
            $('nav a.prev').css({'display': 'none'});   // The 'disable' is set to true so it will disable the any tag with the id of 'prev'.
            break;
        case 'http://localhost/tafara/secondjquerytest.php?Pd=2&Page=1':
                $('nav a.prev').css({'display': 'none'});   // The 'disable' is set to true so it will disable the any tag with the id of 'prev'.
                break;
        case 'http://localhost/tafara/secondjquerytest.php?Pd=3&Page=1':
                $('nav a.prev').css({'display': 'none'});   // The 'disable' is set to true so it will disable the any tag with the id of 'prev'.
                break;
        case 'http://localhost/tafara/secondjquerytest.php?Pd=4&Page=1':
                $('nav a.prev').css({'display': 'none'});   // The 'disable' is set to true so it will disable the any tag with the id of 'prev'.
                break;
        case 'http://localhost/tafara/secondjquerytest.php?Pd=5&Page=1':
                $('nav a.prev').css({'display': 'none'});   // The 'disable' is set to true so it will disable the any tag with the id of 'prev'.
                break;
        case 'http://localhost/tafara/secondjquerytest.php?Pd=6&Page=1':
                $('nav a.prev').css({'display': 'none'});   // The 'disable' is set to true so it will disable the any tag with the id of 'prev'.
                break;
        case 'http://localhost/tafara/secondjquerytest.php?Pd=7&Page=1':
                $('nav a.prev').css({'display': 'none'});   // The 'disable' is set to true so it will disable the any tag with the id of 'prev'.
                break;
        case 'http://localhost/tafara/secondjquerytest.php?Pd=8&Page=1':
                $('nav a.prev').css({'display': 'none'});   // The 'disable' is set to true so it will disable the any tag with the id of 'prev'.
                break;
        case 'http://localhost/tafara/secondjquerytest.php?Pd=9&Page=1':
                $('nav a.prev').css({'display': 'none'});   // The 'disable' is set to true so it will disable the any tag with the id of 'prev'.
                break;
        case 'http://localhost/tafara/secondjquerytest.php?Pd=10&Page=1':
                $('nav a.prev').css({'display': 'none'});   // The 'disable' is set to true so it will disable the any tag with the id of 'prev'.
                break;    
        default:
            $('nav a.prev').css({'display': ''});
            break;
    } 

    }
    if ($(".divs div.fact:visible").prev().length != 0) {

        $(".divs div.fact:visible").prev().show().next().hide();
    }

    else {
      bit = bit - 1;

        if (bit < 0){
            switch (window.location.href) {
                case 'http://localhost/tafara/secondjquerytest.php':
                    alert('Currently you are on very first page. To see more facts click "NEXT" button!');   // The 'disable' is set to true so it will disable the any tag with the id of 'prev'.
                    break;
                case 'http://localhost/tafara/secondjquerytest.php?Page=1':
                    alert('Currently you are on very first page. To see more facts click "NEXT" button!');
                    break;
                case 'http://localhost/tafara/secondjquerytest.php?Pd=1&Page=1':
                    alert('Currently you are on very first page. To see more facts click "NEXT" button!');
                    break;
                case 'http://localhost/tafara/secondjquerytest.php?Pd=2&Page=1':
                        alert('Currently you are on very first page. To see more facts click "NEXT" button!');
                        break;
                case 'http://localhost/tafara/secondjquerytest.php?Pd=3&Page=1':
                        alert('Currently you are on very first page. To see more facts click "NEXT" button!');
                        break;
                case 'http://localhost/tafara/secondjquerytest.php?Pd=4&Page=1':
                        alert('Currently you are on very first page. To see more facts click "NEXT" button!');
                        break;
                case 'http://localhost/tafara/secondjquerytest.php?Pd=5&Page=1':
                        alert('Currently you are on very first page. To see more facts click "NEXT" button!');
                        break;  
                case 'http://localhost/tafara/secondjquerytest.php?Pd=6&Page=1':
                        alert('Currently you are on very first page. To see more facts click "NEXT" button!');
                        break;
                case 'http://localhost/tafara/secondjquerytest.php?Pd=7&Page=1':
                        alert('Currently you are on very first page. To see more facts click "NEXT" button!');
                        break;
                case 'http://localhost/tafara/secondjquerytest.php?Pd=8&Page=1':
                        alert('Currently you are on very first page. To see more facts click "NEXT" button!');
                        break;
                case 'http://localhost/tafara/secondjquerytest.php?Pd=9&Page=1':
                        alert('Currently you are on very first page. To see more facts click "NEXT" button!');
                        break;
                case 'http://localhost/tafara/secondjquerytest.php?Pd=10&Page=1':
                        alert('Currently you are on very first page. To see more facts click "NEXT" button!');
                        break;    
                default:
                    $('nav a.prev').css({'display': ''});
                    break;
            } 

}
        var flag_value2 = 'cool';
        if (window.location.href == "http://localhost/tafara/secondjquerytest.php") {

            window.location.href = window.location.href + "?flag=" + flag_value2; 
        }
        else{
            window.location.href = window.location.href + "&flag=" + flag_value2; 
        }
// $(".divs div.fact:visible").hide();
// $(".divs div.fact:last").show();

}
return false;
}); 


}); 

var pd='';
function nextSetter(pd){
    $('nav a.prev').css({'display': ''});
    $('.divs div.fact:visible').hide();
    $('.divs div.fact:nth-child('+pd+')').show();
};