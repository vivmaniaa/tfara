<!doctype html>
<?php
/*// Turn off all error reporting
error_reporting(1);*/

ob_start();
include("pagination.php");


if($_SERVER['REQUEST_URI'] == "/tafara/secondjquerytest.php?Page=")
	{
		header('Location: '.$_SERVER['PHP_SELF'].'?Page=1');
		ob_end_flush();
	}

	?>

<html>
<title>TFARA SLIDES</title>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.js"></script>

<script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
<script type="text/javascript"> stLight.options({ publisher:'12345',});</script>
	
<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script type="text/javascript" src="secondjquery.js"></script>
<link href='http://fonts.googleapis.com/css?family=Merriweather+Sans:800' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Exo+2:900' rel='stylesheet' type='text/css'> <!-- "TFARA" logo font -->
<link href='http://fonts.googleapis.com/css?family=Coda:400,800' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Flamenco:300,400' rel='stylesheet' type='text/css'><!-- "Slides" logo font font-family: 'Flamenco', cursive;-->
<link href='http://fonts.googleapis.com/css?family=Lobster' rel='stylesheet' type='text/css'><!-- new "slides" logo font font-family: 'Lobster', cursive;-->
<link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:400italic,300' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Pacifico' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Yanone+Kaffeesatz:200' rel='stylesheet' type='text/css'>

<link rel="stylesheet" type="text/css" href="CSS/bootstrap.css">
<link rel="stylesheet" type="text/css" href="CSS/bootstrap.min.css">


<link rel="stylesheet" type="text/css" href="CSS/tfara.css">

<script src="js/bootstrap.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/bootstrap.js"></script>

<link rel="stylesheet" type="text/css" href="CSS/animate.css">
<script src="js/wow.min.js"></script>
<script>
 new WOW().init();
</script> 

  	<script type="text/javascript" src="js/jquery.simple-text-rotator.js"></script>
	<link rel="stylesheet" type="text/css" href="CSS/simpletextrotator.css" />
	<script>
	  $(document).ready(function(){
			$(".logotext .rotate").textrotator({
        animation: "flipCube",
        speed: 6000
      });
	 $(".logosubtext .rotate").textrotator({
        animation: "fade",
        speed: 2000
      });
		});
		
	</script>

		<link rel="stylesheet" type="text/css" href="css/slider-navi-normalize.css" /><!-- for navigation button -->
		<link rel="stylesheet" type="text/css" href="css/slider-navi-demo.css" /><!-- for navigation button -->
		<link rel="stylesheet" type="text/css" href="css/slider-navi-component.css" /><!-- for navigation button -->



</head>


<body class="body">	

<div id="load_screen"><div id="loading"></div></div>

<!-- facebook script starts here -->
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.3&appId=342646252500316";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<!-- facebook script ends here -->

<!--<img src="http://oi57.tinypic.com/1rb71j.jpg"/>-->
 <header>
		<div class="header">
			<div id="logo" class="ad-logo">
				<h2 class="logotext">
		 			<span id="tfara_logo">TFARA</span><span class="rotate" id="slides_logo">Slides, Slides</span>
				</h2>
			</div>
			<div id="head-ad" class="ad-logo"><!-- Place ad here --></div>
		</div>
	</header>

<?php 
		$mango= 3;
		 echo "<div class='divs'>$list</div>"; 
		 
?>
<div class='mango'>hello world!</div>
<div class='mango'>hello earth</div>
<div class='mango'>hello universe if you can hear me!</div>
<div class='mango'>hello world!</div>
<div class='mango'>hello world!</div>
<div class='mango'>hello world!</div>
<div class='mango'>hello world!</div>
<div class='mango'>hello world!</div>
<div class='mango'>hello world!</div>
<div class='mango'>hello world!</div>
<div class='mango'>hello world!</div>
<div class='mango'>hello world!</div>
<div class='mango'>hello world!</div>
<div class='mango'>hello world!</div>
<div class='mango'>hello world!</div>
<div class='mango'>hello world!</div>



<?php
//echo $chick; // this x is comming from position.php.
//$chick = '<a id="demo1"></a>';
	
if(isset($_GET['Pd']))
{
 	$pd = $_GET['Pd'];
 	echo '<div id="bitcounter" class="'.$pd.'"></div>';
	if ($pd == 0 or $pd > 10){
		$pd = 10;
		$pdpn = $_GET['Page'];
		header('Location: '.$_SERVER['PHP_SELF'].'?Pd='.$pd.'&Page='.$pdpn);
		ob_end_flush();
	}
	
	if ($pd < 0){
		$pd = 1;
		$pdpn = $_GET['Page'];
		header('Location: '.$_SERVER['PHP_SELF'].'?Pd='.$pd.'&Page='.$pdpn);
		ob_end_flush();
	}
       
       
	/*echo "<script>
			$(document).ready(function() {
				$('.divs div.fact:visible').hide();
				$('.divs div.fact:nth-child($pd)').show();
			});
		</script>";*/

		echo "<script>
			$(document).ready(function() {
			nextSetter($pd);
			});</script>";

	/*for ($i=1; $i <$pd ; $i++) { 
		
		echo '<script>
			$(document).ready(function() {
			nextSetter();
			});</script>';
	}*/
}
else{
	echo '<div id="bitcounter" class="1"></div>';
}

?>

<?php
if(isset($_GET['flag']))
{
$flag = $_GET['flag'];

if ($flag == 'yes')
{
	$URL = $_SERVER['PHP_SELF'].'?Page='.$next;
header('Location: '.$URL);
ob_end_flush();

}
if ($flag == 'cool')
{
	$URL = $_SERVER['PHP_SELF'].'?Pd=0&Page='.$previous;
header('Location: '.$URL);
ob_end_flush();

}
}

?>

</body>
</html>